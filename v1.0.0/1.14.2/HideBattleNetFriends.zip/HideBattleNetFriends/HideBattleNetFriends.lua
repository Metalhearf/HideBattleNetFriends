BNGetNumFriends = function(...)
	return 0, 0;
end
